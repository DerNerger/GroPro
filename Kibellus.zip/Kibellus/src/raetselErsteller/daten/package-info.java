/**
 * In diesem Paket befinden sich alle Klassen,
 * welche zur Datenschicht gehören.
 * @author Felix Kibellus
 */
package raetselErsteller.daten;