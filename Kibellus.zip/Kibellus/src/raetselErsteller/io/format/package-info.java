/**
 * In diesem Paket befinden sich alle Klassen, welche zur Formatierung
 * von Dateien benötigt werden.
 * @author Felix Kibellus
 */
package raetselErsteller.io.format;