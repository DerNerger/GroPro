/**
 * In diesem Paket befinden sich alle Klassen, welche für Input und
 * Output verwendet werden.
 * @author Felix Kibellus
 */
package raetselErsteller.io;