/**
 * In diesem Paket finden sich alle Klassen zum Kernalgorithmus.
 * @author Felix Kibellus
 */
package raetselErsteller.logik.algorithmus;