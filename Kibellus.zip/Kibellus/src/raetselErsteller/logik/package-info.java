/**
 * Alle Klassen welche relevante Programmlogik oder Klassen mit 
 * Controlling-Aufgaben enthalten befinden sich in diesem Paket.
 * @author Felix Kibellus
 */
package raetselErsteller.logik;