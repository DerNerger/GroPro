/**
 * Dieses Packet dient als uebergeordnetes Basisverzeichnis für alle 
 * Klassen dieses Projekts.
 * @author Felix Kibellus
 */
package raetselErsteller;